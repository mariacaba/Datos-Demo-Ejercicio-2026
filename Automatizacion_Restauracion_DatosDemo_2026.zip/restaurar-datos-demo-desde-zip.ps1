﻿[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [string]$ZipPath = 'C:\Sage Data\Backups\DatosDemo_2026_20260804_143521.zip',
    [string]$SageConfigPath = 'C:\ProgramData\Sage\SageSpainERP.config'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$zipFullPath = [System.IO.Path]::GetFullPath($ZipPath)
$configFullPath = [System.IO.Path]::GetFullPath($SageConfigPath)

if (-not (Test-Path -LiteralPath $zipFullPath -PathType Leaf)) {
    throw "No existe el archivo ZIP: $zipFullPath"
}

if (-not (Test-Path -LiteralPath $configFullPath -PathType Leaf)) {
    throw "No existe la configuración de Sage: $configFullPath"
}

[xml]$sageConfig = Get-Content -LiteralPath $configFullPath
$pathServerValue = $sageConfig.SageRegistry.Global.Paths.PathServer
$dataSourceValue = $sageConfig.SageRegistry.Global.Connection.DataSource

if ([string]::IsNullOrWhiteSpace($pathServerValue)) {
    throw "PathServer está vacío en $configFullPath"
}

$pathServer = [System.IO.Path]::GetFullPath($pathServerValue)
if (-not (Test-Path -LiteralPath $pathServer -PathType Container)) {
    throw "No existe PathServer: $pathServer"
}

# Una ruta local C:\... debe gestionarse desde el propio servidor de Sage/SQL.
$configuredServer = ($dataSourceValue -split '\\')[0]
$localNames = @($env:COMPUTERNAME, 'localhost', '.', '(local)')
if ([System.IO.Path]::IsPathRooted($pathServerValue) -and $configuredServer -notin $localNames) {
    throw "La configuración apunta al servidor $configuredServer. Ejecuta esta automatización en ese servidor; PathServer es una ruta local: $pathServer"
}

$activePath = Join-Path $pathServer 'DatosDemo'
$preparedPath = Join-Path $pathServer 'DatosDemo_2026'
$originalPath = Join-Path $pathServer 'DatosDemo_original'
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$previousOriginalPath = Join-Path $pathServer "DatosDemo_original_anterior_$timestamp"
$extractionPath = Join-Path $pathServer "DatosDemo_descomprimiendo_$([guid]::NewGuid().ToString('N'))"

$runningSage = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
    $_.ProcessName -in @('Sage200c', 'DespachosFLc')
})

if ($runningSage.Count -gt 0) {
    $processList = ($runningSage | ForEach-Object { "$($_.ProcessName) (PID $($_.Id))" }) -join ', '
    throw "Sage 200c /SDC sigue abierto en este equipo: $processList. Ciérralo antes de restaurar los datos."
}

$description = @"
ZIP: $zipFullPath
PathServer: $pathServer
Carpeta activa: $activePath
Respaldo de la actual: $originalPath
"@

if (-not $PSCmdlet.ShouldProcess($activePath, "Restaurar los datos de demostración desde ZIP.`n$description")) {
    return
}

$activeMoved = $false
$previousOriginalMoved = $false
$preparedCreated = $false
$newActiveCreated = $false

try {
    # Paso 1: descomprime y valida sin tocar todavía la carpeta activa.
    Expand-Archive -LiteralPath $zipFullPath -DestinationPath $extractionPath

    $extractedCandidates = @(
        (Join-Path $extractionPath 'DatosDemo'),
        (Join-Path $extractionPath 'DatosDemo_2026'),
        $extractionPath
    )
    $extractedDataPath = $null
    foreach ($candidate in $extractedCandidates) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'DatosDemo.dat') -PathType Leaf) {
            $extractedDataPath = $candidate
            break
        }
    }

    if ($null -eq $extractedDataPath) {
        throw 'El ZIP no contiene una carpeta válida con DatosDemo.dat.'
    }

    $sourceDa1Count = @(Get-ChildItem -LiteralPath $extractedDataPath -Filter '*.da1' -File).Count
    if ($sourceDa1Count -eq 0) {
        throw 'El ZIP no contiene archivos .da1.'
    }

    if (Test-Path -LiteralPath $preparedPath) {
        throw "Ya existe la carpeta de preparación: $preparedPath"
    }

    # Paso 2: copia el contenido descomprimido como DatosDemo_2026.
    Copy-Item -LiteralPath $extractedDataPath -Destination $preparedPath -Recurse
    $preparedCreated = $true

    $preparedDa1Count = @(Get-ChildItem -LiteralPath $preparedPath -Filter '*.da1' -File).Count
    if ($preparedDa1Count -ne $sourceDa1Count) {
        throw "La validación ha fallado: ZIP=$sourceDa1Count, copia=$preparedDa1Count."
    }

    # Conserva un DatosDemo_original previo antes de asignar ese nombre a la carpeta actual.
    if (Test-Path -LiteralPath $originalPath) {
        Move-Item -LiteralPath $originalPath -Destination $previousOriginalPath
        $previousOriginalMoved = $true
    }

    # Paso 3: renombra la carpeta activa como DatosDemo_original.
    if (Test-Path -LiteralPath $activePath) {
        Move-Item -LiteralPath $activePath -Destination $originalPath
        $activeMoved = $true
    }

    # Paso 4: activa DatosDemo_2026 con el nombre requerido por Sage.
    Move-Item -LiteralPath $preparedPath -Destination $activePath
    $preparedCreated = $false
    $newActiveCreated = $true

    [pscustomobject]@{
        Status = 'OK'
        Zip = $zipFullPath
        PathServer = $pathServer
        ActiveDirectory = $activePath
        OriginalDirectory = if ($activeMoved) { $originalPath } else { $null }
        PreviousOriginalDirectory = if ($previousOriginalMoved) { $previousOriginalPath } else { $null }
        Da1Files = $sourceDa1Count
    } | Format-List
}
catch {
    $restoreError = $_

    if ($newActiveCreated -and (Test-Path -LiteralPath $activePath)) {
        Remove-Item -LiteralPath $activePath -Recurse -Force
        $newActiveCreated = $false
    }

    if ($activeMoved -and -not (Test-Path -LiteralPath $activePath) -and (Test-Path -LiteralPath $originalPath)) {
        Move-Item -LiteralPath $originalPath -Destination $activePath
        $activeMoved = $false
    }

    if ($previousOriginalMoved -and -not (Test-Path -LiteralPath $originalPath) -and (Test-Path -LiteralPath $previousOriginalPath)) {
        Move-Item -LiteralPath $previousOriginalPath -Destination $originalPath
        $previousOriginalMoved = $false
    }

    throw "No se pudo restaurar DatosDemo. Se ha recuperado la situación anterior cuando era necesario. Error: $($restoreError.Exception.Message)"
}
finally {
    if ($preparedCreated -and (Test-Path -LiteralPath $preparedPath)) {
        Remove-Item -LiteralPath $preparedPath -Recurse -Force
    }
    if (Test-Path -LiteralPath $extractionPath) {
        Remove-Item -LiteralPath $extractionPath -Recurse -Force
    }
}
