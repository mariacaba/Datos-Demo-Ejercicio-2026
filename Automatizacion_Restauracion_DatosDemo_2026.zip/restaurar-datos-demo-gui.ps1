﻿Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -Namespace RestoreLauncher -Name NativeWindow -MemberDefinition @'
    [System.Runtime.InteropServices.DllImport("kernel32.dll")]
    public static extern System.IntPtr GetConsoleWindow();

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    public static extern bool ShowWindow(System.IntPtr windowHandle, int command);
'@

$consoleWindow = [RestoreLauncher.NativeWindow]::GetConsoleWindow()
if ($consoleWindow -ne [System.IntPtr]::Zero) {
    [RestoreLauncher.NativeWindow]::ShowWindow($consoleWindow, 0) | Out-Null
}

[System.Windows.Forms.Application]::EnableVisualStyles()

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$restoreScript = Join-Path $scriptDirectory 'restaurar-datos-demo-desde-zip.ps1'
$defaultZip = 'C:\Sage Data\Backups\DatosDemo_2026_20260804_143521.zip'
$defaultConfig = 'C:\ProgramData\Sage\SageSpainERP.config'

if (-not (Test-Path -LiteralPath $restoreScript -PathType Leaf)) {
    [System.Windows.Forms.MessageBox]::Show(
        "No se encuentra el script de restauración:`n$restoreScript",
        'Restauración de DatosDemo',
        'OK',
        'Error'
    ) | Out-Null
    exit 1
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Restaurar empresa de demostración - Sage 200c /SDC'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = New-Object System.Drawing.Size(820, 690)
$form.MinimumSize = New-Object System.Drawing.Size(836, 729)
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$form.BackColor = [System.Drawing.Color]::White

$header = New-Object System.Windows.Forms.Panel
$header.Dock = 'Top'
$header.Height = 72
$header.BackColor = [System.Drawing.Color]::FromArgb(0, 120, 60)
$form.Controls.Add($header)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'Restauración de DatosDemo'
$title.ForeColor = [System.Drawing.Color]::White
$title.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 20)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(24, 17)
$header.Controls.Add($title)

$warningPanel = New-Object System.Windows.Forms.Panel
$warningPanel.Location = New-Object System.Drawing.Point(20, 90)
$warningPanel.Size = New-Object System.Drawing.Size(780, 72)
$warningPanel.BackColor = [System.Drawing.Color]::FromArgb(255, 238, 204)
$warningPanel.BorderStyle = 'FixedSingle'
$form.Controls.Add($warningPanel)

$warningIcon = New-Object System.Windows.Forms.Label
$warningIcon.Text = '⚠'
$warningIcon.Font = New-Object System.Drawing.Font('Segoe UI Symbol', 24)
$warningIcon.ForeColor = [System.Drawing.Color]::FromArgb(170, 85, 0)
$warningIcon.AutoSize = $true
$warningIcon.Location = New-Object System.Drawing.Point(16, 13)
$warningPanel.Controls.Add($warningIcon)

$warning = New-Object System.Windows.Forms.Label
$warning.Text = 'Debe ejecutarse con Sage 200c /SDC cerrado en todos los equipos'
$warning.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 12)
$warning.ForeColor = [System.Drawing.Color]::FromArgb(120, 55, 0)
$warning.AutoSize = $true
$warning.Location = New-Object System.Drawing.Point(62, 22)
$warningPanel.Controls.Add($warning)

$stepsGroup = New-Object System.Windows.Forms.GroupBox
$stepsGroup.Text = 'Pasos que realizará la automatización'
$stepsGroup.Location = New-Object System.Drawing.Point(20, 176)
$stepsGroup.Size = New-Object System.Drawing.Size(780, 178)
$form.Controls.Add($stepsGroup)

$steps = @(
    '1. Descomprimir y validar la base de datos.',
    '2. Renombrar la carpeta actual como DatosDemo_original.',
    '3. Copiar la carpeta preparada como DatosDemo_2026 en PathServer.',
    '4. Renombrar la copia como DatosDemo para activarla.',
    '5. Leer PathServer y comprobar el servidor desde SageSpainERP.config.'
)

for ($index = 0; $index -lt $steps.Count; $index++) {
    $stepLabel = New-Object System.Windows.Forms.Label
    $stepLabel.Text = $steps[$index]
    $stepLabel.AutoSize = $true
    $stepLabel.Location = New-Object System.Drawing.Point(20, (29 + ($index * 27)))
    $stepsGroup.Controls.Add($stepLabel)
}

$sourceLabel = New-Object System.Windows.Forms.Label
$sourceLabel.Text = 'Archivo ZIP:'
$sourceLabel.AutoSize = $true
$sourceLabel.Location = New-Object System.Drawing.Point(20, 372)
$form.Controls.Add($sourceLabel)

$zipTextBox = New-Object System.Windows.Forms.TextBox
$zipTextBox.Text = $defaultZip
$zipTextBox.Location = New-Object System.Drawing.Point(20, 397)
$zipTextBox.Size = New-Object System.Drawing.Size(675, 28)
$form.Controls.Add($zipTextBox)

$browseButton = New-Object System.Windows.Forms.Button
$browseButton.Text = 'Examinar...'
$browseButton.Location = New-Object System.Drawing.Point(704, 395)
$browseButton.Size = New-Object System.Drawing.Size(96, 31)
$form.Controls.Add($browseButton)

$configLabel = New-Object System.Windows.Forms.Label
$configLabel.Text = 'Configuración: C:\ProgramData\Sage\SageSpainERP.config'
$configLabel.AutoSize = $true
$configLabel.ForeColor = [System.Drawing.Color]::DimGray
$configLabel.Location = New-Object System.Drawing.Point(20, 438)
$form.Controls.Add($configLabel)

$statusGroup = New-Object System.Windows.Forms.GroupBox
$statusGroup.Text = 'Comprobación de seguridad'
$statusGroup.Location = New-Object System.Drawing.Point(20, 470)
$statusGroup.Size = New-Object System.Drawing.Size(780, 103)
$form.Controls.Add($statusGroup)

$sageStatus = New-Object System.Windows.Forms.Label
$sageStatus.AutoSize = $true
$sageStatus.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10)
$sageStatus.Location = New-Object System.Drawing.Point(20, 28)
$statusGroup.Controls.Add($sageStatus)

$verifyButton = New-Object System.Windows.Forms.Button
$verifyButton.Text = 'Verificar de nuevo'
$verifyButton.Location = New-Object System.Drawing.Point(616, 22)
$verifyButton.Size = New-Object System.Drawing.Size(142, 31)
$statusGroup.Controls.Add($verifyButton)

$confirmation = New-Object System.Windows.Forms.CheckBox
$confirmation.Text = 'Confirmo que Sage 200c /SDC está cerrado también en los demás equipos.'
$confirmation.AutoSize = $true
$confirmation.Location = New-Object System.Drawing.Point(20, 65)
$statusGroup.Controls.Add($confirmation)

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Location = New-Object System.Drawing.Point(20, 590)
$progress.Size = New-Object System.Drawing.Size(560, 25)
$progress.Style = 'Marquee'
$progress.MarqueeAnimationSpeed = 25
$progress.Visible = $false
$form.Controls.Add($progress)

$restoreButton = New-Object System.Windows.Forms.Button
$restoreButton.Text = 'Iniciar restauración'
$restoreButton.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
$restoreButton.BackColor = [System.Drawing.Color]::FromArgb(0, 120, 60)
$restoreButton.ForeColor = [System.Drawing.Color]::White
$restoreButton.FlatStyle = 'Flat'
$restoreButton.UseVisualStyleBackColor = $false
$restoreButton.Location = New-Object System.Drawing.Point(600, 584)
$restoreButton.Size = New-Object System.Drawing.Size(200, 38)
$restoreButton.Enabled = $false
$restoreButton.Add_Paint({
    param($sender, $eventArgs)

    $backgroundBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(0, 120, 60))
    try {
        $eventArgs.Graphics.FillRectangle($backgroundBrush, $sender.ClientRectangle)
        $textBounds = [System.Drawing.Rectangle]::Inflate($sender.ClientRectangle, -2, -2)
        $textFlags = [System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor
            [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor
            [System.Windows.Forms.TextFormatFlags]::SingleLine
        [System.Windows.Forms.TextRenderer]::DrawText(
            $eventArgs.Graphics,
            $sender.Text,
            $sender.Font,
            $textBounds,
            [System.Drawing.Color]::White,
            $textFlags
        )
    }
    finally {
        $backgroundBrush.Dispose()
    }
})
$form.Controls.Add($restoreButton)

$resultLabel = New-Object System.Windows.Forms.Label
$resultLabel.Text = 'Esperando comprobación.'
$resultLabel.AutoSize = $true
$resultLabel.ForeColor = [System.Drawing.Color]::DimGray
$resultLabel.Location = New-Object System.Drawing.Point(20, 632)
$form.Controls.Add($resultLabel)

function Get-SageProcesses {
    return @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -in @('Sage200c', 'DespachosFLc')
    })
}

function Update-SafetyStatus {
    $running = @(Get-SageProcesses)
    if ($running.Count -eq 0) {
        $sageStatus.Text = '✓ Sage 200c /SDC no está abierto en este equipo.'
        $sageStatus.ForeColor = [System.Drawing.Color]::FromArgb(0, 120, 60)
        $script:localSageClosed = $true
    }
    else {
        $processList = ($running | ForEach-Object { "$($_.ProcessName) (PID $($_.Id))" }) -join ', '
        $sageStatus.Text = "✗ Sage 200c /SDC está abierto: $processList"
        $sageStatus.ForeColor = [System.Drawing.Color]::Firebrick
        $script:localSageClosed = $false
    }

    $restoreButton.Enabled = $script:localSageClosed
}

$browseButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = 'Seleccionar copia comprimida de DatosDemo'
    $dialog.Filter = 'Archivos ZIP (*.zip)|*.zip|Todos los archivos (*.*)|*.*'
    if (Test-Path -LiteralPath (Split-Path -Parent $zipTextBox.Text)) {
        $dialog.InitialDirectory = Split-Path -Parent $zipTextBox.Text
    }
    if ($dialog.ShowDialog() -eq 'OK') {
        $zipTextBox.Text = $dialog.FileName
    }
    $dialog.Dispose()
})

$verifyButton.Add_Click({ Update-SafetyStatus })
$confirmation.Add_CheckedChanged({ Update-SafetyStatus })

$restoreButton.Add_Click({
    Update-SafetyStatus
    if (-not $restoreButton.Enabled) {
        return
    }

    if (-not $confirmation.Checked) {
        [System.Windows.Forms.MessageBox]::Show(
            'Antes de continuar, confirma que Sage 200c /SDC está cerrado en todos los equipos y marca la casilla.',
            'Confirmación requerida',
            'OK',
            'Warning'
        ) | Out-Null
        return
    }

    if (-not (Test-Path -LiteralPath $zipTextBox.Text -PathType Leaf)) {
        [System.Windows.Forms.MessageBox]::Show(
            'Selecciona un archivo ZIP válido.',
            'Restauración de DatosDemo',
            'OK',
            'Warning'
        ) | Out-Null
        return
    }

    $answer = [System.Windows.Forms.MessageBox]::Show(
        "Se sustituirá la carpeta DatosDemo activa y se conservará como DatosDemo_original.`n`n¿Deseas continuar?",
        'Confirmar restauración',
        'YesNo',
        'Warning'
    )
    if ($answer -ne 'Yes') {
        return
    }

    $restoreButton.Enabled = $false
    $browseButton.Enabled = $false
    $verifyButton.Enabled = $false
    $confirmation.Enabled = $false
    $zipTextBox.Enabled = $false
    $progress.Visible = $true
    $resultLabel.Text = 'Restaurando y validando los datos...'
    $resultLabel.ForeColor = [System.Drawing.Color]::FromArgb(0, 90, 150)
    $form.Refresh()

    try {
        $escapedScript = $restoreScript.Replace("'", "''")
        $escapedZip = $zipTextBox.Text.Replace("'", "''")
        $escapedConfig = $defaultConfig.Replace("'", "''")
        $command = "& '$escapedScript' -ZipPath '$escapedZip' -SageConfigPath '$escapedConfig' -Confirm:`$false"

        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = 'powershell.exe'
        $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
        $startInfo.Arguments = "-NoProfile -ExecutionPolicy Bypass -EncodedCommand $encodedCommand"
        $startInfo.UseShellExecute = $false
        $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true

        $process = [System.Diagnostics.Process]::Start($startInfo)
        $standardOutput = $process.StandardOutput.ReadToEnd()
        $standardError = $process.StandardError.ReadToEnd()
        $process.WaitForExit()

        if ($process.ExitCode -ne 0) {
            $message = if ([string]::IsNullOrWhiteSpace($standardError)) { $standardOutput } else { $standardError }
            throw $message.Trim()
        }

        $resultLabel.Text = 'Restauración finalizada correctamente.'
        $resultLabel.ForeColor = [System.Drawing.Color]::FromArgb(0, 120, 60)
        [System.Windows.Forms.MessageBox]::Show(
            "La restauración ha finalizado correctamente.`n`n$standardOutput",
            'Restauración de DatosDemo',
            'OK',
            'Information'
        ) | Out-Null
    }
    catch {
        $resultLabel.Text = 'La restauración no se ha completado.'
        $resultLabel.ForeColor = [System.Drawing.Color]::Firebrick
        [System.Windows.Forms.MessageBox]::Show(
            $_.Exception.Message,
            'Error durante la restauración',
            'OK',
            'Error'
        ) | Out-Null
    }
    finally {
        $progress.Visible = $false
        $browseButton.Enabled = $true
        $verifyButton.Enabled = $true
        $confirmation.Enabled = $true
        $zipTextBox.Enabled = $true
        Update-SafetyStatus
    }
})

$form.Add_Shown({ Update-SafetyStatus })
[void]$form.ShowDialog()
$form.Dispose()
