using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new RestoreForm());
    }
}

internal sealed class RestoreForm : Form
{
    private const string DefaultZip = @"C:\Sage Data\Backups\DatosDemo_2026_20260804_143521.zip";
    private const string DefaultConfig = @"C:\ProgramData\Sage\SageSpainERP.config";

    private readonly TextBox zipTextBox;
    private readonly Label sageStatus;
    private readonly CheckBox remoteConfirmation;
    private readonly Button restoreButton;
    private readonly Button browseButton;
    private readonly Button verifyButton;
    private readonly ProgressBar progress;
    private readonly Label resultLabel;
    private readonly Label targetPathLabel;
    private bool localSageClosed;
    private bool restoring;

    public RestoreForm()
    {
        Text = "Restaurar DatosDemo · Sage 200c /SDC";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(980, 720);
        MinimumSize = new Size(996, 759);
        Font = new Font("Segoe UI", 10F);
        BackColor = Color.FromArgb(244, 247, 246);
        AutoScaleMode = AutoScaleMode.Dpi;

        var header = new Panel
        {
            Dock = DockStyle.Top,
            Height = 94,
            BackColor = Color.FromArgb(13, 63, 48)
        };
        Controls.Add(header);

        header.Controls.Add(new Label
        {
            Text = "SAGE 200c  ·  HERRAMIENTA DE MANTENIMIENTO",
            ForeColor = Color.FromArgb(173, 221, 198),
            Font = new Font("Segoe UI Semibold", 9F),
            AutoSize = true,
            Location = new Point(26, 14)
        });

        header.Controls.Add(new Label
        {
            Text = "Restaurar empresa de demostración",
            ForeColor = Color.White,
            Font = new Font("Segoe UI Semibold", 22F),
            AutoSize = true,
            Location = new Point(24, 37)
        });

        header.Controls.Add(new Label
        {
            Text = "Proceso guiado y con recuperación automática",
            ForeColor = Color.FromArgb(206, 229, 218),
            Font = new Font("Segoe UI", 10F),
            AutoSize = true,
            Location = new Point(626, 52)
        });

        var warningPanel = new Panel
        {
            Location = new Point(24, 112),
            Size = new Size(932, 64),
            BackColor = Color.FromArgb(255, 246, 226),
            BorderStyle = BorderStyle.FixedSingle
        };
        Controls.Add(warningPanel);

        warningPanel.Controls.Add(new Label
        {
            Text = "!",
            Font = new Font("Segoe UI Semibold", 14F),
            ForeColor = Color.White,
            BackColor = Color.FromArgb(218, 128, 0),
            TextAlign = ContentAlignment.MiddleCenter,
            Size = new Size(34, 34),
            Location = new Point(18, 14)
        });

        warningPanel.Controls.Add(new Label
        {
            Text = "Debe ejecutarse con Sage 200c /SDC cerrado en todos los equipos",
            Font = new Font("Segoe UI Semibold", 11F),
            ForeColor = Color.FromArgb(109, 67, 0),
            AutoSize = true,
            Location = new Point(68, 12)
        });

        warningPanel.Controls.Add(new Label
        {
            Text = "El botón de restauración permanecerá bloqueado mientras Sage esté abierto en este equipo.",
            Font = new Font("Segoe UI", 9F),
            ForeColor = Color.FromArgb(128, 92, 32),
            AutoSize = true,
            Location = new Point(68, 36)
        });

        var stepsGroup = new GroupBox
        {
            Text = "  Qué va a ocurrir  ",
            Font = new Font("Segoe UI Semibold", 10F),
            Location = new Point(24, 194),
            Size = new Size(430, 420),
            BackColor = Color.White
        };
        Controls.Add(stepsGroup);

        AddStep(stepsGroup, 1, 30, "Descomprimir", "Abrir y validar el contenido del ZIP.");
        AddStep(stepsGroup, 2, 102, "Proteger la instalación actual", "Guardarla como DatosDemo_original.");
        AddStep(stepsGroup, 3, 174, "Preparar la copia", "Copiarla como DatosDemo_2026 en PathServer.");
        AddStep(stepsGroup, 4, 246, "Activar la demostración", "Renombrar la copia final como DatosDemo.");
        AddStep(stepsGroup, 5, 318, "Comprobar el servidor", "Usar PathServer de SageSpainERP.config.");

        var actionGroup = new GroupBox
        {
            Text = "  Preparar restauración  ",
            Font = new Font("Segoe UI Semibold", 10F),
            Location = new Point(474, 194),
            Size = new Size(482, 420),
            BackColor = Color.White
        };
        Controls.Add(actionGroup);

        actionGroup.Controls.Add(new Label
        {
            Text = "1. Selecciona la copia comprimida",
            Font = new Font("Segoe UI Semibold", 10F),
            AutoSize = true,
            Location = new Point(20, 29)
        });

        zipTextBox = new TextBox
        {
            Text = DefaultZip,
            Location = new Point(20, 57),
            Size = new Size(338, 28),
            Font = new Font("Segoe UI", 9F)
        };
        actionGroup.Controls.Add(zipTextBox);

        browseButton = new Button
        {
            Text = "Examinar...",
            Location = new Point(366, 54),
            Size = new Size(96, 32),
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.White
        };
        browseButton.Click += BrowseButtonClick;
        actionGroup.Controls.Add(browseButton);

        actionGroup.Controls.Add(new Label
        {
            Text = "Destino detectado desde PathServer",
            Font = new Font("Segoe UI Semibold", 9F),
            AutoSize = true,
            ForeColor = Color.FromArgb(72, 86, 80),
            Location = new Point(20, 101)
        });

        targetPathLabel = new Label
        {
            Text = ReadConfiguredTarget(),
            AutoEllipsis = true,
            ForeColor = Color.FromArgb(0, 108, 72),
            BackColor = Color.FromArgb(235, 247, 241),
            Padding = new Padding(10, 8, 10, 8),
            Location = new Point(20, 126),
            Size = new Size(442, 39)
        };
        actionGroup.Controls.Add(targetPathLabel);

        actionGroup.Controls.Add(new Label
        {
            Text = "2. Comprueba que Sage está cerrado",
            Font = new Font("Segoe UI Semibold", 10F),
            AutoSize = true,
            Location = new Point(20, 184)
        });

        sageStatus = new Label
        {
            AutoSize = true,
            Font = new Font("Segoe UI Semibold", 10F),
            Location = new Point(20, 216)
        };
        actionGroup.Controls.Add(sageStatus);

        verifyButton = new Button
        {
            Text = "Verificar de nuevo",
            Location = new Point(320, 207),
            Size = new Size(142, 32),
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.White
        };
        verifyButton.Click += delegate { UpdateSafetyStatus(); };
        actionGroup.Controls.Add(verifyButton);

        remoteConfirmation = new CheckBox
        {
            Text = "Confirmo que Sage 200c /SDC está cerrado también\nen los demás equipos.",
            AutoSize = false,
            Size = new Size(442, 48),
            Location = new Point(20, 257)
        };
        remoteConfirmation.CheckedChanged += delegate { UpdateSafetyStatus(); };
        actionGroup.Controls.Add(remoteConfirmation);

        progress = new ProgressBar
        {
            Location = new Point(24, 671),
            Size = new Size(932, 10),
            Style = ProgressBarStyle.Marquee,
            MarqueeAnimationSpeed = 25,
            Visible = false
        };
        Controls.Add(progress);

        restoreButton = new Button
        {
            Text = "Iniciar restauración",
            Font = new Font("Segoe UI Semibold", 13F),
            BackColor = Color.FromArgb(0, 120, 60),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            UseVisualStyleBackColor = false,
            FlatAppearance = { BorderSize = 0 },
            Location = new Point(20, 332),
            Size = new Size(442, 52),
            Enabled = false
        };
        restoreButton.Paint += delegate(object sender, PaintEventArgs paintArgs)
        {
            using (var backgroundBrush = new SolidBrush(Color.FromArgb(0, 120, 60)))
                paintArgs.Graphics.FillRectangle(backgroundBrush, restoreButton.ClientRectangle);

            Rectangle textBounds = Rectangle.Inflate(restoreButton.ClientRectangle, -2, -2);
            TextRenderer.DrawText(
                paintArgs.Graphics,
                restoreButton.Text,
                restoreButton.Font,
                textBounds,
                Color.White,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
        };
        restoreButton.Click += RestoreButtonClick;
        actionGroup.Controls.Add(restoreButton);

        resultLabel = new Label
        {
            Text = "Listo para comprobar el entorno.",
            AutoSize = true,
            ForeColor = Color.DimGray,
            Location = new Point(24, 640)
        };
        Controls.Add(resultLabel);

        FormClosing += delegate(object sender, FormClosingEventArgs args)
        {
            if (restoring)
            {
                args.Cancel = true;
                MessageBox.Show("Espera a que termine la restauración.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        };
        Shown += delegate { UpdateSafetyStatus(); };
    }

    private static void AddStep(Control parent, int number, int top, string title, string description)
    {
        var badge = new Label
        {
            Text = number.ToString(),
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI Semibold", 11F),
            ForeColor = Color.White,
            BackColor = Color.FromArgb(0, 120, 60),
            Size = new Size(36, 36),
            Location = new Point(20, top)
        };
        parent.Controls.Add(badge);

        parent.Controls.Add(new Label
        {
            Text = title,
            Font = new Font("Segoe UI Semibold", 10F),
            ForeColor = Color.FromArgb(28, 47, 39),
            AutoSize = true,
            Location = new Point(70, top - 1)
        });

        parent.Controls.Add(new Label
        {
            Text = description,
            Font = new Font("Segoe UI", 9F),
            ForeColor = Color.FromArgb(94, 105, 100),
            AutoSize = true,
            Location = new Point(70, top + 23)
        });
    }

    private static string ReadConfiguredTarget()
    {
        try
        {
            var document = new XmlDocument();
            document.Load(DefaultConfig);
            XmlNode pathNode = document.SelectSingleNode("/SageRegistry/Global/Paths/PathServer");
            if (pathNode != null && !string.IsNullOrWhiteSpace(pathNode.InnerText))
                return Path.Combine(pathNode.InnerText.Trim(), "DatosDemo");
        }
        catch
        {
        }
        return "No se ha podido leer PathServer";
    }

    private static Process[] GetSageProcesses()
    {
        return Process.GetProcesses().Where(delegate(Process process)
        {
            return string.Equals(process.ProcessName, "Sage200c", StringComparison.OrdinalIgnoreCase)
                || string.Equals(process.ProcessName, "DespachosFLc", StringComparison.OrdinalIgnoreCase);
        }).ToArray();
    }

    private void UpdateSafetyStatus()
    {
        Process[] running = GetSageProcesses();
        localSageClosed = running.Length == 0;
        if (localSageClosed)
        {
            sageStatus.Text = "✓ Sage 200c /SDC no está abierto en este equipo.";
            sageStatus.ForeColor = Color.FromArgb(0, 120, 60);
        }
        else
        {
            string processes = string.Join(", ", running.Select(delegate(Process process)
            {
                return process.ProcessName + " (PID " + process.Id + ")";
            }).ToArray());
            sageStatus.Text = "✗ Sage 200c /SDC está abierto: " + processes;
            sageStatus.ForeColor = Color.Firebrick;
        }

        restoreButton.Enabled = !restoring && localSageClosed;
    }

    private void BrowseButtonClick(object sender, EventArgs args)
    {
        using (var dialog = new OpenFileDialog())
        {
            dialog.Title = "Seleccionar copia comprimida de DatosDemo";
            dialog.Filter = "Archivos ZIP (*.zip)|*.zip|Todos los archivos (*.*)|*.*";
            string currentDirectory = Path.GetDirectoryName(zipTextBox.Text);
            if (!string.IsNullOrEmpty(currentDirectory) && Directory.Exists(currentDirectory))
                dialog.InitialDirectory = currentDirectory;
            if (dialog.ShowDialog(this) == DialogResult.OK)
                zipTextBox.Text = dialog.FileName;
        }
    }

    private async void RestoreButtonClick(object sender, EventArgs args)
    {
        UpdateSafetyStatus();
        if (!restoreButton.Enabled)
            return;

        if (!remoteConfirmation.Checked)
        {
            MessageBox.Show(
                "Antes de continuar, confirma que Sage 200c /SDC está cerrado en todos los equipos y marca la casilla.",
                "Confirmación requerida",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        string zipPath = zipTextBox.Text.Trim();
        if (!File.Exists(zipPath))
        {
            MessageBox.Show("Selecciona un archivo ZIP válido.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        DialogResult answer = MessageBox.Show(
            "Se sustituirá la carpeta DatosDemo activa y se conservará como DatosDemo_original.\n\n¿Deseas continuar?",
            "Confirmar restauración",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning);
        if (answer != DialogResult.Yes)
            return;

        SetBusy(true);
        resultLabel.Text = "Restaurando y validando los datos...";
        resultLabel.ForeColor = Color.FromArgb(0, 90, 150);

        try
        {
            RestoreResult result = await Task.Run(delegate { return Restore(zipPath, DefaultConfig); });
            resultLabel.Text = "Restauración finalizada correctamente.";
            resultLabel.ForeColor = Color.FromArgb(0, 120, 60);
            MessageBox.Show(
                "La restauración ha finalizado correctamente.\n\n"
                + "Carpeta activa: " + result.ActiveDirectory + "\n"
                + "Carpeta original: " + result.OriginalDirectory + "\n"
                + "Archivos .da1: " + result.Da1Files,
                Text,
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        catch (Exception exception)
        {
            resultLabel.Text = "La restauración no se ha completado.";
            resultLabel.ForeColor = Color.Firebrick;
            MessageBox.Show(exception.Message, "Error durante la restauración", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            SetBusy(false);
            UpdateSafetyStatus();
        }
    }

    private void SetBusy(bool busy)
    {
        restoring = busy;
        progress.Visible = busy;
        browseButton.Enabled = !busy;
        verifyButton.Enabled = !busy;
        remoteConfirmation.Enabled = !busy;
        zipTextBox.Enabled = !busy;
        restoreButton.Enabled = false;
    }

    private static RestoreResult Restore(string zipPath, string configPath)
    {
        if (GetSageProcesses().Length > 0)
            throw new InvalidOperationException("Sage 200c /SDC sigue abierto en este equipo.");
        if (!File.Exists(zipPath))
            throw new FileNotFoundException("No existe el archivo ZIP.", zipPath);
        if (!File.Exists(configPath))
            throw new FileNotFoundException("No existe la configuración de Sage.", configPath);

        var document = new XmlDocument();
        document.Load(configPath);
        XmlNode pathNode = document.SelectSingleNode("/SageRegistry/Global/Paths/PathServer");
        XmlNode dataSourceNode = document.SelectSingleNode("/SageRegistry/Global/Connection/DataSource");
        if (pathNode == null || string.IsNullOrWhiteSpace(pathNode.InnerText))
            throw new InvalidDataException("PathServer está vacío en SageSpainERP.config.");

        string pathServer = Path.GetFullPath(pathNode.InnerText.Trim());
        if (!Directory.Exists(pathServer))
            throw new DirectoryNotFoundException("No existe PathServer: " + pathServer);

        string dataSource = dataSourceNode == null ? string.Empty : dataSourceNode.InnerText.Trim();
        string configuredServer = dataSource.Split('\\')[0];
        if (Path.IsPathRooted(pathNode.InnerText)
            && !string.IsNullOrEmpty(configuredServer)
            && !string.Equals(configuredServer, Environment.MachineName, StringComparison.OrdinalIgnoreCase)
            && !string.Equals(configuredServer, "localhost", StringComparison.OrdinalIgnoreCase)
            && configuredServer != "."
            && !string.Equals(configuredServer, "(local)", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                "La configuración apunta al servidor " + configuredServer
                + ". Ejecuta esta aplicación en ese servidor. PathServer: " + pathServer);
        }

        string activePath = Path.Combine(pathServer, "DatosDemo");
        string preparedPath = Path.Combine(pathServer, "DatosDemo_2026");
        string originalPath = Path.Combine(pathServer, "DatosDemo_original");
        string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string previousOriginalPath = Path.Combine(pathServer, "DatosDemo_original_anterior_" + timestamp);
        string extractionPath = Path.Combine(pathServer, "DatosDemo_descomprimiendo_" + Guid.NewGuid().ToString("N"));

        bool preparedCreated = false;
        bool previousOriginalMoved = false;
        bool activeMoved = false;
        bool newActiveCreated = false;
        int sourceDa1Count = 0;

        try
        {
            ZipFile.ExtractToDirectory(zipPath, extractionPath);
            string extractedDataPath = FindDataDirectory(extractionPath);
            sourceDa1Count = Directory.GetFiles(extractedDataPath, "*.da1", SearchOption.TopDirectoryOnly).Length;
            if (sourceDa1Count == 0)
                throw new InvalidDataException("El ZIP no contiene archivos .da1.");
            if (Directory.Exists(preparedPath))
                throw new IOException("Ya existe la carpeta de preparación: " + preparedPath);

            CopyDirectory(extractedDataPath, preparedPath);
            preparedCreated = true;
            int preparedDa1Count = Directory.GetFiles(preparedPath, "*.da1", SearchOption.TopDirectoryOnly).Length;
            if (preparedDa1Count != sourceDa1Count || !File.Exists(Path.Combine(preparedPath, "DatosDemo.dat")))
                throw new InvalidDataException("La validación de la copia preparada ha fallado.");

            if (Directory.Exists(originalPath))
            {
                Directory.Move(originalPath, previousOriginalPath);
                previousOriginalMoved = true;
            }
            if (Directory.Exists(activePath))
            {
                Directory.Move(activePath, originalPath);
                activeMoved = true;
            }

            Directory.Move(preparedPath, activePath);
            preparedCreated = false;
            newActiveCreated = true;

            return new RestoreResult
            {
                ActiveDirectory = activePath,
                OriginalDirectory = activeMoved ? originalPath : "(no existía)",
                Da1Files = sourceDa1Count
            };
        }
        catch
        {
            if (newActiveCreated && Directory.Exists(activePath))
                Directory.Delete(activePath, true);
            if (activeMoved && !Directory.Exists(activePath) && Directory.Exists(originalPath))
                Directory.Move(originalPath, activePath);
            if (previousOriginalMoved && !Directory.Exists(originalPath) && Directory.Exists(previousOriginalPath))
                Directory.Move(previousOriginalPath, originalPath);
            throw;
        }
        finally
        {
            if (preparedCreated && Directory.Exists(preparedPath))
                Directory.Delete(preparedPath, true);
            if (Directory.Exists(extractionPath))
                Directory.Delete(extractionPath, true);
        }
    }

    private static string FindDataDirectory(string extractionPath)
    {
        string[] candidates =
        {
            Path.Combine(extractionPath, "DatosDemo"),
            Path.Combine(extractionPath, "DatosDemo_2026"),
            extractionPath
        };
        foreach (string candidate in candidates)
        {
            if (File.Exists(Path.Combine(candidate, "DatosDemo.dat")))
                return candidate;
        }

        string manifest = Directory.GetFiles(extractionPath, "DatosDemo.dat", SearchOption.AllDirectories).FirstOrDefault();
        if (manifest == null)
            throw new InvalidDataException("El ZIP no contiene una carpeta válida con DatosDemo.dat.");
        return Path.GetDirectoryName(manifest);
    }

    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (string file in Directory.GetFiles(source))
            File.Copy(file, Path.Combine(destination, Path.GetFileName(file)), false);
        foreach (string directory in Directory.GetDirectories(source))
            CopyDirectory(directory, Path.Combine(destination, Path.GetFileName(directory)));
    }

    private sealed class RestoreResult
    {
        public string ActiveDirectory { get; set; }
        public string OriginalDirectory { get; set; }
        public int Da1Files { get; set; }
    }
}
