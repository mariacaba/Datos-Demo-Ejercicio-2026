@echo off
setlocal

echo Instalacion de los datos de demostracion 2026 para Sage 200c
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar-datos-demo-2026.ps1"
set "DEPLOY_EXIT_CODE=%ERRORLEVEL%"

echo.
if not "%DEPLOY_EXIT_CODE%"=="0" (
    echo La instalacion no se ha completado. Revisa el mensaje anterior.
) else (
    echo Instalacion finalizada correctamente.
)

pause
exit /b %DEPLOY_EXIT_CODE%
