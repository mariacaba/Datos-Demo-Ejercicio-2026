@echo off
setlocal

echo Restauracion de DatosDemo desde el archivo ZIP
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0restaurar-datos-demo-desde-zip.ps1"
set "RESTORE_EXIT_CODE=%ERRORLEVEL%"

echo.
if not "%RESTORE_EXIT_CODE%"=="0" (
    echo La restauracion no se ha completado. Revisa el mensaje anterior.
) else (
    echo Restauracion finalizada correctamente.
)

pause
exit /b %RESTORE_EXIT_CODE%
