﻿[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [string]$SourceDir = 'C:\Users\maria.caba\OneDrive - Sage Software, Inc\Documents\DamosDemo2026\DatosDemo_2026',
    [string]$SageDataDir = 'C:\Sage Data\Sage 200c'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$sourcePath = [System.IO.Path]::GetFullPath($SourceDir)
$sageDataPath = [System.IO.Path]::GetFullPath($SageDataDir)
$activePath = Join-Path $sageDataPath 'DatosDemo'
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupPath = Join-Path $sageDataPath "DatosDemo_original_$timestamp"
$stagingPath = Join-Path $sageDataPath "DatosDemo_preparando_$([guid]::NewGuid().ToString('N'))"

if (-not (Test-Path -LiteralPath $sourcePath -PathType Container)) {
    throw "No existe la carpeta preparada: $sourcePath"
}

if (-not (Test-Path -LiteralPath (Join-Path $sourcePath 'DatosDemo.dat') -PathType Leaf)) {
    throw "La carpeta preparada no contiene DatosDemo.dat: $sourcePath"
}

if (-not (Test-Path -LiteralPath $sageDataPath -PathType Container)) {
    throw "No existe el directorio de datos de Sage: $sageDataPath"
}

$sourceDa1Count = @(Get-ChildItem -LiteralPath $sourcePath -Filter '*.da1' -File).Count
if ($sourceDa1Count -eq 0) {
    throw "La carpeta preparada no contiene archivos .da1: $sourcePath"
}

$runningSage = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
    $_.ProcessName -in @('Sage200c', 'DespachosFLc')
})

if ($runningSage.Count -gt 0) {
    $processList = ($runningSage | ForEach-Object { "$($_.ProcessName) (PID $($_.Id))" }) -join ', '
    throw "Sage 200c sigue abierto en este equipo: $processList. Ciérralo antes de ejecutar el despliegue."
}

$description = @"
Origen: $sourcePath
Destino activo: $activePath
Copia de seguridad: $backupPath
Archivos .da1: $sourceDa1Count
"@

if (-not $PSCmdlet.ShouldProcess($activePath, "Instalar los datos de demostración 2026.`n$description")) {
    return
}

$activeMoved = $false

try {
    # Prepara y valida la copia antes de tocar la carpeta activa.
    Copy-Item -LiteralPath $sourcePath -Destination $stagingPath -Recurse

    $stagingDa1Count = @(Get-ChildItem -LiteralPath $stagingPath -Filter '*.da1' -File).Count
    if ($stagingDa1Count -ne $sourceDa1Count) {
        throw "La validación de la copia ha fallado: origen=$sourceDa1Count, copia=$stagingDa1Count."
    }

    if (-not (Test-Path -LiteralPath (Join-Path $stagingPath 'DatosDemo.dat') -PathType Leaf)) {
        throw 'La copia preparada no contiene DatosDemo.dat.'
    }

    # Paso 1: conserva la carpeta actualmente activa.
    if (Test-Path -LiteralPath $activePath) {
        Move-Item -LiteralPath $activePath -Destination $backupPath
        $activeMoved = $true
    }

    # Pasos 2 y 3: coloca la copia y la activa con el nombre DatosDemo.
    Move-Item -LiteralPath $stagingPath -Destination $activePath

    [pscustomobject]@{
        Status = 'OK'
        ActiveDirectory = $activePath
        BackupDirectory = if ($activeMoved) { $backupPath } else { $null }
        Da1Files = $sourceDa1Count
    } | Format-List
}
catch {
    $deploymentError = $_

    if ($activeMoved -and -not (Test-Path -LiteralPath $activePath) -and (Test-Path -LiteralPath $backupPath)) {
        Move-Item -LiteralPath $backupPath -Destination $activePath
    }

    throw "No se pudo instalar DatosDemo. Se ha restaurado la situación anterior cuando era necesario. Error: $($deploymentError.Exception.Message)"
}
finally {
    if (Test-Path -LiteralPath $stagingPath) {
        Remove-Item -LiteralPath $stagingPath -Recurse -Force
    }
}
