﻿param(
    [Parameter(Mandatory = $true)]
    [string]$SourceDir,

    [Parameter(Mandatory = $true)]
    [string]$DestinationDir,

    [int]$SourceLatestYear = 2020,
    [int]$TargetLatestYear = 2026
)

$ErrorActionPreference = 'Stop'

$sourcePath = [System.IO.Path]::GetFullPath($SourceDir)
$destinationPath = [System.IO.Path]::GetFullPath($DestinationDir)
$yearShift = $TargetLatestYear - $SourceLatestYear
$yearsToShift = @(($SourceLatestYear - 1), $SourceLatestYear)

if (-not (Test-Path -LiteralPath $sourcePath -PathType Container)) {
    throw "No existe la carpeta origen: $sourcePath"
}

if (Test-Path -LiteralPath $destinationPath) {
    throw "La carpeta destino ya existe: $destinationPath"
}

Copy-Item -LiteralPath $sourcePath -Destination $destinationPath -Recurse

$changedBySourceYear = [ordered]@{}
$changedBySourceYear[($SourceLatestYear - 1).ToString()] = 0
$changedBySourceYear[$SourceLatestYear.ToString()] = 0

$summary = [ordered]@{
    Source = $sourcePath
    Destination = $destinationPath
    YearShift = $yearShift
    FilesScanned = 0
    FilesChanged = 0
    DateValuesChanged = 0
    ExerciseValuesChanged = 0
    ChangedBySourceYear = $changedBySourceYear
}

$yearFieldPattern = '(?i)(ejercicio|año|anyo|year)'
$dateTypes = @(7, 133, 134, 135)
$adPersistADTG = 0

function Set-AdoFieldValue {
    param(
        [Parameter(Mandatory = $true)]$Field,
        [Parameter(Mandatory = $true)][object]$Value
    )

    $Field.GetType().InvokeMember(
        'Value',
        [Reflection.BindingFlags]::SetProperty,
        $null,
        $Field,
        @($Value),
        [Globalization.CultureInfo]::InvariantCulture
    ) | Out-Null
}

foreach ($file in Get-ChildItem -LiteralPath $destinationPath -Filter '*.da1' -File) {
    $summary.FilesScanned++
    $recordset = New-Object -ComObject ADODB.Recordset
    $changed = $false
    $temporaryPath = "$($file.FullName).updated"
    $currentContext = 'apertura'

    try {
        $recordset.Open($file.FullName)
        $dateFields = @()
        $yearFields = @()

        foreach ($field in $recordset.Fields) {
            if ($field.Type -in $dateTypes) {
                $dateFields += $field.Name
            }
            elseif ($field.Name -match $yearFieldPattern) {
                $yearFields += $field.Name
            }
        }

        while (-not $recordset.EOF) {
            foreach ($fieldName in $dateFields) {
                $currentContext = "fecha $fieldName"
                $dateField = $recordset.Fields.Item($fieldName)
                $value = $dateField.Value
                if ($null -eq $value -or $value -eq [DBNull]::Value) {
                    continue
                }

                $dateValue = [datetime]$value
                if ($dateValue.Year -in $yearsToShift) {
                    $sourceYear = $dateValue.Year.ToString()
                    Set-AdoFieldValue -Field $dateField -Value ($dateValue.AddYears($yearShift))
                    $recordset.Update()
                    $summary.DateValuesChanged++
                    $summary.ChangedBySourceYear[$sourceYear]++
                    $changed = $true
                }
            }

            foreach ($fieldName in $yearFields) {
                $currentContext = "ejercicio $fieldName"
                $yearField = $recordset.Fields.Item($fieldName)
                $value = $yearField.Value
                if ($null -eq $value -or $value -eq [DBNull]::Value) {
                    continue
                }

                $numericYear = 0
                if ([int]::TryParse($value.ToString(), [ref]$numericYear) -and $numericYear -in $yearsToShift) {
                    $targetYear = $numericYear + $yearShift
                    if ($yearField.Type -in @(8, 129, 130, 200, 201, 202, 203)) {
                        Set-AdoFieldValue -Field $yearField -Value ($targetYear.ToString())
                    }
                    else {
                        Set-AdoFieldValue -Field $yearField -Value $targetYear
                    }
                    $recordset.Update()
                    $summary.ExerciseValuesChanged++
                    $summary.ChangedBySourceYear[$numericYear.ToString()]++
                    $changed = $true
                }
            }
            $recordset.MoveNext()
        }

        if ($changed) {
            $recordset.Save($temporaryPath, $adPersistADTG)
            $recordset.Close()
            Move-Item -LiteralPath $temporaryPath -Destination $file.FullName -Force
            $summary.FilesChanged++
        }
        else {
            $recordset.Close()
        }
    }
    catch {
        throw "Error en $($file.Name), $currentContext`: $($_.Exception.Message)"
    }
    finally {
        if (Test-Path -LiteralPath $temporaryPath) {
            Remove-Item -LiteralPath $temporaryPath -Force
        }
        if ($recordset.State -ne 0) {
            $recordset.Close()
        }
        [Runtime.InteropServices.Marshal]::ReleaseComObject($recordset) | Out-Null
    }
}

[pscustomobject]$summary | ConvertTo-Json -Depth 4
